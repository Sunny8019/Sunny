# Objective

**Complete the given Spring Boot Rest Application for Product Inventory Management**
  - The Application in based on adding, managing and updating the product.
  - It uses Spring Data JPA to interact with h2 in-memory database 

 * Complete the code as per the instructions in this document and the source code  
 * Make sure all the provided tests are passing for completeness of submission
 * Submit within the allotted time.

## Complete the following as per the requirement

### Model class - package com.inventory.product.model 

 Complete the Product model class by mapping Entity Relations using Spring Data JPA

### Repository Interface - package com.inventory.product.repository

Complete ProductRepository interface for Data access using Spring Data JPA with H2 in memory Database

### Service Class - package com.inventory.product.service

Implementing the methods specified in the ProductService interface. These methods invoke the appropriate repository methods for interacting with the database and throws appropriate custom exceptions.

### ErrorHandling - package com.inventory.product.errorHandler

Implement Global Exception handling for handling Custom Exceptions

### Products Rest APIs Controller - package com.inventory.product.controller

Implement the handler methods in ProductController class as per the below REST endpoints definition

### API endpoints to be provided

| HTTP Method | path                          | Description                    |
|-------------|-------------------------------|--------------------------------|
| GET         | /api/products/{productId}     | get an product by product code | 
| POST        | /api/products                 | create a new product           |
| GET         | /api/products/productname     | get products by name           |
| GET         | /api/products/productcategory | get products by category       |
| PUT         | /api/products                 | update a product               |


**IMP. NOTE :** 

To complete the code
- Read the instructions given as comments in the class files
- Understand the failure messages when running the provided test cases   