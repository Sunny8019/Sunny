package com.inventory.product.commander.service;

import com.inventory.product.MethodExecutor;
import com.inventory.product.errorhandler.ProductExistsException;
import com.inventory.product.errorhandler.ProductNotFoundException;
import com.inventory.product.model.Product;
import com.inventory.product.repository.ProductRepository;
import com.inventory.product.service.ProductServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
public class ProductServiceImplTest {

    @Mock
    private ProductRepository repository;


    @InjectMocks
    private ProductServiceImpl service;

    private Product productOne, productTwo, productThree,productOneUpdated;

    @BeforeEach
    public void setUp() {
        productOne = new Product(1,"Samsung LED",22222,"Electronics");
        productTwo = new Product(2,"Samsung Galaxy",222232,"Electronics");
        productThree = new Product(3,"Harry Potter",300,"Books");
        productOneUpdated = new Product(1,"Samsung LED",30000,"Electronics");
    }

    @AfterEach
    public void tearDown() {
        productOne = null;
        productTwo = null;
        productThree = null;
        productOneUpdated = null;
    }

    @Test
    public void givenProductWhenDoesNotExistThenReturnAddedProduct() throws ProductExistsException {
        when(MethodExecutor.executeMethod(repository, "findById",
                new Class[]{Integer.class},
                new Object[]{anyInt()}))
                .thenReturn(Optional.empty());
        when(MethodExecutor.executeMethod(repository, "save",
                new Class[]{Object.class},
                new Object[]{any(Product.class)}))
                .thenReturn(productOne);

        Product product = service.addProduct(productOne);
        assertEquals(product, productOne);


    }


    @Test
    public void givenProductWhenExistsThenThrowException() throws ProductExistsException {
        when(MethodExecutor.executeMethod(repository, "findById",
                new Class[]{Integer.class},
                new Object[]{anyInt()}))
                .thenReturn(Optional.of(productOne));

        assertThrows(ProductExistsException.class, () -> service.addProduct(productOne));
    }

    @Test
    public void givenProductIdWhenExistsThenReturnProduct() throws ProductNotFoundException {
        when(MethodExecutor.executeMethod(repository, "findById",
                new Class[]{Integer.class},
                new Object[]{anyInt()}))
                .thenReturn(Optional.of(productOne));

        assertEquals(service.getProductByProductId(1), productOne);
    }

    @Test
    public void givenProductIdWhenDoesNotExistThenThrowException() throws ProductNotFoundException {
        when(MethodExecutor.executeMethod(repository, "findById",
                new Class[]{Integer.class},
                new Object[]{anyInt()}))
                .thenReturn(Optional.empty());

        assertThrows(ProductNotFoundException.class, () -> service.getProductByProductId(9));
    }


    @Test
    public void givenProductCategoryWhenExistsThenReturnListOfClaim() throws ProductNotFoundException {
        when(MethodExecutor.executeMethod(repository, "findProductByProductCategory",
                new Class[]{String.class},
                new Object[]{anyString()}))
                .thenReturn(List.of(productOne, productTwo));

        List<Product> productsByCategory = service.getProductByProductCategory("Electronics");
        assertEquals(2, productsByCategory.size());
    }

    @Test
    public void givenProductCategoryWhenDoesNotExistThenThrowException() throws ProductNotFoundException {
        when(MethodExecutor.executeMethod(repository, "findProductByProductCategory",
                new Class[]{String.class},
                new Object[]{anyString()}))
                .thenReturn(Collections.emptyList());

        assertThrows(ProductNotFoundException.class, () -> service.getProductByProductCategory("eee"));
    }


    @Test
    public void givenProductNameWhenExistsThenReturnListOfClaim() throws ProductNotFoundException {
        when(MethodExecutor.executeMethod(repository, "findProductByProductName",
                new Class[]{String.class},
                new Object[]{anyString()}))
                .thenReturn(List.of(productOne));

        List<Product> product = service.getProductByProductName("Samsung LED");
        assertEquals(1, product.size());
    }

    public void givenProductNameWhenDoesNotExistThenThrowException() throws ProductNotFoundException {
        when(MethodExecutor.executeMethod(repository, "findProductByProductName",
                new Class[]{String.class},
                new Object[]{anyString()}))
                .thenReturn(Collections.emptyList());

        assertThrows(ProductNotFoundException.class, () -> service.getProductByProductName("Hjjj"));
    }

    @Test
    public void givenProductIdWhenExistsThenReturnUpdatedProduct() throws ProductNotFoundException {
        when(MethodExecutor.executeMethod(repository, "findById",
                new Class[]{Integer.class},
                new Object[]{1}))
                .thenReturn(Optional.of(productOne));
        when(MethodExecutor.executeMethod(repository, "save",
                new Class[]{Object.class},
                new Object[]{any(Product.class)}))
                .thenReturn(productOneUpdated);

        assertEquals(productOneUpdated,service.updateProduct(productOneUpdated));

    }

}