package com.inventory.product.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.inventory.product.errorhandler.ProductExistsException;
import com.inventory.product.errorhandler.ProductNotFoundException;
import com.inventory.product.service.ProductService;
import com.inventory.product.model.Product;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import static org.mockito.Mockito.*;

@WebMvcTest(controllers = ProductController.class)
public class ProductControllerTest {

    private Product productOne, productTwo, productThree,productOneUpdated;

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductService service;

    @Autowired
    private ObjectMapper mapper;

    @BeforeEach
    public void setUp() {
        productOne = new Product(1,"Samsung LED",22222,"Electronics");
        productTwo = new Product(2,"Samsung Galaxy",222232,"Electronics");
        productThree = new Product(3,"Harry Potter",300,"Books");
        productOneUpdated = new Product(1,"Samsung LED",30000,"Electronics");
    }

    @AfterEach
    public void tearDown() {
        productOne = null;
        productTwo = null;
        productThree = null;
        productOneUpdated = null;
    }

    @Test
    public void givenProductDetailsWhenCreatedThenReturnSuccessCode() throws Exception {
        when(service.addProduct(any(Product.class))).thenReturn(productOne);

        MvcResult mvcResult = mockMvc.perform(post("/api/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(productOne)))
                .andExpect(status().isCreated())
                .andReturn();

        assertThat(mapper.readValue(mvcResult.getResponse().getContentAsString(), Product.class))
                .usingRecursiveComparison().isEqualTo(productOne);
    }

    @Test
    public void givenExistingProductDetailsWhenCreatedThenReturnConflictCode() throws Exception {
        when(service.addProduct(any(Product.class))).thenThrow(new ProductExistsException());

        mockMvc.perform(post("/api/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(productOne)))
                .andExpect(status().isConflict());
    }

    @Test
    public void givenProductIdWhenExistsThenReturnProduct() throws Exception {
        when(service.getProductByProductId(anyInt())).thenReturn(productOne);

        MvcResult mvcResult = mockMvc
                .perform(get("/api/products/1"))
                .andExpect(status().is2xxSuccessful())
                .andReturn();

        assertThat(mapper.readValue(mvcResult.getResponse().getContentAsString().split(":")[1].substring(0,1), String.class))
                .isEqualTo(productOne.getProductCode().toString());
    }

    @Test
    public void givenProductCategoryWhenDoesNotExistsThenReturnNotFound() throws Exception {
        when(service.getProductByProductCategory(anyString())).thenThrow(new ProductNotFoundException());

        mockMvc.perform(get("/api/products/productcategory?productCategory=f"))
                .andExpect(status().isNotFound());

    }

    @Test
    public void givenProductCategoryWhenExistsThenReturnProducts() throws Exception {
        when(service.getProductByProductCategory(anyString())).thenReturn(List.of(productOne,productTwo));

        MvcResult mvcResult = mockMvc
                .perform(get("/api/products/productcategory?productCategory=Electronics"))
                .andExpect(status().is2xxSuccessful())
                .andReturn();

        assertThat(mapper.readValue(mvcResult.getResponse().getContentAsString(),List.class)).hasSize(2);
    }

    @Test
    public void givenProductNameWhenDoesNotExistsThenReturnNotFound() throws Exception {
        when(service.getProductByProductName(anyString())).thenThrow(new ProductNotFoundException());

        mockMvc.perform(get("/api/products/productname?productName=Samsung"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void givenProductNameWhenExistsThenReturnProducts() throws Exception {
        when(service.getProductByProductName(anyString()))
                .thenReturn(List.of(productOne));

        MvcResult mvcResult = mockMvc
                .perform(get("/api/products/productname?productName=Samsung LED"))
                .andExpect(status().isOk())
                .andReturn();

        assertThat(mapper.readValue(mvcResult.getResponse().getContentAsString(), List.class))
                .hasSize(1);
    }

    @Test
    public void givenProductExistsThenReturnUpdatedProduct() throws Exception {
        when(service.updateProduct(any(Product.class))).thenReturn(productOneUpdated);

        MvcResult settled = mockMvc.perform(put("/api/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(new Product(1,"Samsung LED",30000,"Electronics"))))
                .andExpect(status().isOk())
                .andReturn();

        assertThat(mapper.readValue(settled.getResponse().getContentAsString(), Product.class))
                .usingRecursiveComparison().isEqualTo(productOneUpdated);

    }
}