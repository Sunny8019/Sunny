package com.inventory.product.ittests;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inventory.product.ProductServiceApplication;
import com.inventory.product.model.Product;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        classes = ProductServiceApplication.class
)
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ProductServiceIntegrationTest {

    public static final String PRODUCT_BASE_URL = "/api/products";
    private Product productOne;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper mapper;

    @BeforeEach
    public void setUp() {
        productOne = new Product(1,"Samsung LED",30002,"Elctronics");
    }

    @AfterEach
    public void tearDown() {
        productOne = null;
    }

    @Test
    @Order(1)
    public void givenProductDetailsThenCreateNewProduct() throws Exception {
        mockMvc.perform(
                        post(PRODUCT_BASE_URL)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(toJson(productOne)))
                .andExpect(status().isCreated())
                .andReturn();
    }

    @Test
    @Order(1)
    public void givenProductWhenProductExistsThenReturnProduct() throws Exception {
        mockMvc.perform(
                        get(PRODUCT_BASE_URL + "/1"))
                .andExpect(status().isOk())
                .andReturn();

    }

    private String toJson(final Object obj) throws JsonProcessingException {
        return mapper.writeValueAsString(obj);
    }

}
