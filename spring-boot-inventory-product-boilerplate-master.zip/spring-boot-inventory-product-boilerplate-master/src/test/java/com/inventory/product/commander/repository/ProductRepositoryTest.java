package com.inventory.product.commander.repository;

import com.inventory.product.MethodExecutor;
import com.inventory.product.model.Product;
import com.inventory.product.repository.ProductRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class ProductRepositoryTest {

    @Autowired
    private ProductRepository productRepository;

    private Product productOne, productTwo, productThree;

    @BeforeEach
    public void setUp() {
        productOne = new Product(1,"Samsung LED",22222,"Electronics");
        productTwo = new Product(2,"Samsung Galaxy",222232,"Electronics");
        productThree = new Product(3,"Harry Potter",300,"Books");

        MethodExecutor.executeMethod(productRepository, "save",
                new Class[]{Object.class},
                new Object[]{productOne});
        MethodExecutor.executeMethod(productRepository, "save",
                new Class[]{Object.class},
                new Object[]{productTwo});
        MethodExecutor.executeMethod(productRepository, "save",
                new Class[]{Object.class},
                new Object[]{productThree});
    }

    @Test
    public void givenProductIdWhenNotExistsThenReturnEmptyOptional() {
        Optional<Product> optionalProduct = (Optional<Product>) MethodExecutor.executeMethod(productRepository, "findById",
                new Class[]{Object.class},
                new Object[]{99});
        assertThat(optionalProduct).isEmpty();
    }

    @Test
    public void givenProductIdWhenExistsThenReturnOptionalWithProduct() {
        Optional<Product> optionalProduct = (Optional<Product>) MethodExecutor.executeMethod(productRepository, "findById",
                new Class[]{Object.class},
                new Object[]{1});
        assertThat(optionalProduct.isPresent());
    }

    @Test
    public void givenProductCategoryWhenNotExistsThenReturnEmptyList() {

        List<Product> products = (List<Product>) MethodExecutor.executeMethod(productRepository, "findProductByProductCategory",
                new Class[]{String.class},
                new Object[]{"Electr"});
        assertThat(products.size()).isZero();

    }

    @Test
    public void givenProductCategoryWhenExistsThenReturnProductList() {
        List<Product> products = (List<Product>) MethodExecutor.executeMethod(productRepository, "findProductByProductCategory",
                new Class[]{String.class},
                new Object[]{"Electronics"});
        assertThat(products.size()).isEqualTo(2);
    }

    @Test
    public void givenProductNameWhenExistsThenReturnProductList() {
        List<Product> claims = (List<Product>) MethodExecutor.executeMethod(productRepository, "findProductByProductName",
                new Class[]{String.class},
                new Object[]{"Harry Potter"});

        assertThat(claims.size()).isEqualTo(1);

    }


    @AfterEach
    public void tearDown() {
        MethodExecutor.executeMethod(productRepository, "deleteAll",
                new Class[]{},
                new Object[]{});
        productOne = null;
        productTwo = null;
        productThree = null;

    }
}
