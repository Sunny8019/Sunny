package com.inventory.product.service;

import com.inventory.product.errorhandler.ProductExistsException;
import com.inventory.product.errorhandler.ProductNotFoundException;
import com.inventory.product.model.Product;
import com.inventory.product.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/*
Add appropriate annotation/s to create a bean for service layer
Implement all the functionality based on the ProductService Interface
 */
@Service
public class ProductServiceImpl implements ProductService{

    /*
      Inject the repository bean
     */

}
