package com.inventory.product.controller;


import com.inventory.product.errorhandler.ProductExistsException;
import com.inventory.product.errorhandler.ProductNotFoundException;
import com.inventory.product.service.ProductService;
import com.inventory.product.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/*
Add appropriate annotation/s to create a bean for handling http requests for the rest api
 */

public class ProductController {

    /*
    Inject the service object here
     */

    /*
    Create API endpoints as per the requirement given below
    */

    /*
     description  :  adding new product
     api endpoint : /api/products
     http request : POST
     request body : product details
     success response:
            body: created product    - http status: 201
     failure response:
            If a product exists with same product code
            body: failure message   - http status: 409
     */


    /*
     description  : get a product by product code
     api endpoint : /api/products/{id}
     http request : GET
     success response:
            body: Product Details   - http status: 200
     failure response:
            If no product exists for given criteria
            body: failure message - http status: 404
  */

    /*
     description  : update the product for given product code
     api endpoint : /api/products
     http request : PUT
     request body : product
     success response:
            body: updated product    - http status: 200
     failure response:
            If no product exists for given criteria
            body: failure message - http status: 404
  */
    /*
     description  : get products for given product name
     api endpoint : /api/products/productname
     http request : GET
     success response:
            body: list of products    - http status: 200
     failure response:
            If no product exists for given criteria
            body: failure message - http status: 404
  */

    /*
     description  : get products for given product category
     api endpoint : /api/products/productcategory
     http request : GET
     success response:
            body: list of products    - http status: 200
     failure response:
            If no product exists for given criteria
            body: failure message - http status: 404
  */



}
