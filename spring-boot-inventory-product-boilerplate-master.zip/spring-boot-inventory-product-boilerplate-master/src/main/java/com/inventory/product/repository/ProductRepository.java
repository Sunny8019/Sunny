package com.inventory.product.repository;

import com.inventory.product.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


/*
Add appropriate annotation/s and implement required interface/s to create a bean for handling database interactions using Data JPA
*/
@Repository
public interface ProductRepository extends JpaRepository<Product,Integer> {

    /* **USE FIND KEYWORD SYNTAX to define data access methods** */

    /*
         Define a method to get product by product name, returning a list of products
    */
    // findProductByProductName(String productName);
        /*
        Define a method to get all products by product category, returning list of products
    */
    // findProductByProductCategory(String productCategory);
}
