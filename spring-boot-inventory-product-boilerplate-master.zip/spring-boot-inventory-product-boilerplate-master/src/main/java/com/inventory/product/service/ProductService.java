package com.inventory.product.service;


import com.inventory.product.errorhandler.ProductExistsException;
import com.inventory.product.errorhandler.ProductNotFoundException;
import com.inventory.product.model.Product;

import java.util.List;

public interface ProductService {

    Product addProduct(Product product) throws ProductExistsException;
    Product getProductByProductId(int productId) throws ProductNotFoundException;
    Product updateProduct(Product product) throws ProductNotFoundException;
    List<Product> getProductByProductName(String productName)  throws ProductNotFoundException;
    List<Product> getProductByProductCategory(String productCategory)  throws ProductNotFoundException;

}
